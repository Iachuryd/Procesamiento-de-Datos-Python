# Taller Ejercicios de Python — Datos a Gran Escala (Lab_01)

## Presentación

Este repositorio contiene los cuadernos de Python desarrollados para el taller de la asignatura **Datos a Gran Escala**, correspondiente al [Lab_01](https://github.com/corredor-john/ExploratoryDataAnalisys/tree/main/DatosGranEscala/Lab_01).

Cada cuaderno aborda un tema puntual de Python, incluye un membrete de identificación del autor, la documentación personal de cada instrucción/actividad, la ejecución del código y una conclusión final.

**Autor:** Ana Sofía [Apellido]
**Curso:** Datos a Gran Escala
**Fecha de entrega:** [pendiente por definir en clase]

## Estructura del repositorio

| # | Cuaderno | Tema | Peso en rúbrica |
|---|---|---|---|
| 1 | `01_cadenas.ipynb` | Cadenas (Strings) | 10% |
| 2 | `02_tuplas.ipynb` | Tuplas | 10% |
| 3 | `03_listas.ipynb` | Listas | 10% |
| 4 | `04_conjuntos.ipynb` | Conjuntos (Sets) | 10% |
| 5 | `05_diccionarios.ipynb` | Diccionarios | 10% |
| 6 | `06_condiciones.ipynb` | Condiciones | 10% |
| 7 | `07_bucles.ipynb` | Bucles | 10% |
| 8 | `08_funciones.ipynb` | Funciones | 10% |
| 9 | `09_clases.ipynb` | Clases | 10% |
| 10 | `10_bono.ipynb` | Bono | 5% |

Adicionalmente, la presentación general del repositorio (este README + organización de carpetas) corresponde al **15%** de la rúbrica.

## Contenido de cada cuaderno

Todos los cuadernos siguen la misma estructura:

1. **Membrete de identificación** — tabla con tema, autor, ID/código, curso, fecha y una breve descripción personal del cuaderno.
2. **Ejercicios** — por cada instrucción: documentación breve y personal de lo que pide el ejercicio, celda de código con la ejecución de la actividad, y una conclusión puntual del ejercicio.
3. **Conclusiones del cuaderno** — reflexión personal de cierre sobre lo aprendido en el tema.

## Cómo usar este repositorio

1. Clonar o descargar el repositorio.
2. Abrir cada cuaderno con Jupyter Notebook / JupyterLab / VS Code.
3. Completar el membrete con tus datos.
4. Desarrollar y documentar cada ejercicio en su propio cuaderno.

## Rúbrica de la entrega

| Criterio | Peso |
|---|---|
| Presentación (+Repositorio) | 15% |
| Cadenas | 10% |
| Tuplas | 10% |
| Listas | 10% |
| Conjuntos | 10% |
| Diccionarios | 10% |
| Condiciones | 10% |
| Bucles | 10% |
| Funciones | 10% |
| Clases | 10% |
| Bono | 5% |
